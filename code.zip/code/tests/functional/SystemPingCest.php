<?php namespace App\Tests;
use App\Tests\FunctionalTester;
use Codeception\Util\HttpCode;

class SystemPingCest
{
    const SYSTEM_NAME = "derbysoft";
    const SYSTEM_STATUS = 'working';

    public function _before(FunctionalTester $I)
    {
    }

    // tests
    public function pingDispatcher(FunctionalTester $I)
    {
        $I->amGoingTo("Ask Adapter if is working fine");
        $I->sendGET('/ping');
        $I->seeResponseCodeIs(HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'system' => 'string',
            'date' => 'string:date',
            'status' => 'string'
        ]);
        $I->canSeeResponseContainsJson([
            'system' => self::SYSTEM_NAME,
            'status' => self::SYSTEM_STATUS
        ]);
    }
}
