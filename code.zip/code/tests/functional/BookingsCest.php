<?php

declare(strict_types=1);

namespace App\Tests;

use Codeception\Util\HttpCode;

class BookingsCest
{
    const EXAMPLE_BOOKING_OBJECT = [];

    public function bookRoom(FunctionalTester $I)
    {
        $I->amGoingTo("Place new booking");
        $I->sendPOST('/bookings');
        $I->seeResponseCodeIs(HttpCode::CREATED);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'id' => 'string'
        ]);
        $response = $I->grabResponse();
        $response = json_decode($response, true);
        $I->getId($response['id']);
    }

    /**
     * @depends bookRoom
     */
    public function cancelBooking(FunctionalTester $I)
    {
        $I->amGoingTo("Cancel my booking");
        $I->sendPOST(sprintf('/bookings/%s', $I->putId()));
        $I->seeResponseCodeIs(HttpCode::NO_CONTENT);
        $I->seeResponseIsJson();
    }
}