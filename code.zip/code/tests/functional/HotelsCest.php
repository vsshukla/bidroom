<?php

declare(strict_types=1);

namespace App\Tests;

use Codeception\Util\HttpCode;

class HotelsCest
{
    const DS_CM_NAME = 'dummy';
    const TEST_HOTEL_UUID = '1e452465-32bf-418c-a737-398d98a2db79';
    const NON_EXISTENT_HOTEL_UUID = '5536dd64-1315-48e1-afe5-f26977fcff4d';
    const EXAMPLE_INVALID_LIMIT = 'invalid_limit';
    const EXAMPLE_LIMIT = 10;
    const EXAMPLE_OFFSET = 0;
    const HOTEL_STRUCTURE = [
        'uuid' => 'string',
        'eid' => 'string|int' //todo define it
    ];
    const EXAMPLE_HOTEL_OBJECT = [
        'uuid' => self::TEST_HOTEL_UUID
    ];

    public function _before(FunctionalTester $I)
    {
    }

    // tests
    public function fetchHotelFromCMList(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET('/hotels');
        $I->seeResponseCodeIs(HttpCode::OK);
        $I->seeResponseIsJson();
        $I->comment("Hotel key should contain array. When there is no hotels it should be empty array.");
        $I->seeResponseMatchesJsonType([
            'hotels' => 'array'
        ]);
    }

    public function fetchHotelFromCMListWithAdditionalParams(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET('/hotels', [
            'limit' => self::EXAMPLE_LIMIT,
            'offset' => self::EXAMPLE_OFFSET
        ]);
        $I->seeResponseCodeIs(HttpCode::OK);
        $I->seeResponseIsJson();
        $I->comment("Hotel key should contain array. When there is no hotels it should be empty array.");
        $I->seeResponseMatchesJsonType([
            'hotels' => 'array'
        ]);
    }

    public function sendIncorrectParams(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET('/hotels', [
            'limit' => self::EXAMPLE_INVALID_LIMIT,
            'offset' => self::EXAMPLE_OFFSET
        ]);
        $I->seeResponseCodeIs(HttpCode::BAD_REQUEST);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'error' => 'string',
            'query' => 'array'
        ]);
        $I->canSeeResponseContainsJson([
            'error' => 'Query contains invalid parameters',
            'query' => [
                'system' => self::DS_CM_NAME,
                'limit' => self::EXAMPLE_INVALID_LIMIT,
                'offset' => self::EXAMPLE_OFFSET
            ]
        ]);
    }

    public function fetchSingleHotel(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET(sprintf('/hotels/%s', self::TEST_HOTEL_UUID));
        $I->seeResponseCodeIs(HttpCode::OK);
        $I->seeResponseIsJson();
        $I->comment("Hotel key should contain array. When there is no hotels it should be empty array.");
        $I->seeResponseMatchesJsonType([
            'hotel' => self::HOTEL_STRUCTURE
        ]);
        $I->canSeeResponseContainsJson([
            'hotel' => self::EXAMPLE_HOTEL_OBJECT
        ]);
    }

    public function tryToFetchNonExistentSingleHotel(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET(sprintf('/hotels/%s', self::TEST_HOTEL_UUID));
        $I->seeResponseCodeIs(HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'error' => 'string',
            'query' => 'array'
        ]);
        $I->canSeeResponseContainsJson([
            'error' => 'Hotel not found',
            'query' => [
                'uuid' => self::NON_EXISTENT_HOTEL_UUID,
                'system' => self::DS_CM_NAME
            ]
        ]);
    }

    public function fetchRatePlans(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET(sprintf('/hotels/%s/ratePlans', self::TEST_HOTEL_UUID));
        $I->seeResponseCodeIs(HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'ratePlans' => 'array' //even empty
        ]);
    }
}