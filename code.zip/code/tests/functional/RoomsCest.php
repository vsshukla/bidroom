<?php

declare(strict_types=1);

namespace App\Tests;

use Codeception\Util\HttpCode;

class RoomsCest
{
    const DS_CM_NAME = 'derbysoft';
    const TEST_HOTEL_UUID = '1e452465-32bf-418c-a737-398d98a2db79';
    const NON_EXISTENT_HOTEL_UUID = '5536dd64-1315-48e1-afe5-f26977fcff4d';

    public function fetchHotelRoomsList(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET(sprintf('/hotels/%s/rooms', self::TEST_HOTEL_UUID));
        $I->seeResponseCodeIs(HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'rooms' => 'array' //even empty
        ]);
    }

    public function tryToFetchRoomsFromNonExistentHotel(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch hotel list from specific channel manager");
        $I->sendGET(sprintf('/hotels/%s/rooms', self::NON_EXISTENT_HOTEL_UUID));
        $I->seeResponseCodeIs(HttpCode::NOT_FOUND);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'error' => 'string'
        ]);
        $I->canSeeResponseContainsJson([
            'error' => 'Hotel not found',
            'query' => [
                'system' => self::DS_CM_NAME,
                'uuid' => self::NON_EXISTENT_HOTEL_UUID
            ]
        ]);
    }
}