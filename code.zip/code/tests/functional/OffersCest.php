<?php

declare(strict_types=1);

namespace App\Tests;

use Codeception\Util\HttpCode;

class OffersCest
{
    const DS_CM_NAME = 'derbysoft';
    const TEST_HOTEL_UUID = '1e452465-32bf-418c-a737-398d98a2db79';
    const NON_EXISTENT_HOTEL_UUID = '5536dd64-1315-48e1-afe5-f26977fcff4d';
    const EXAMPLE_INVALID_SYSTEM = 'invalid_system';
    const EXAMPLE_LIMIT = 10;
    const EXAMPLE_OFFSET = 0;
    const EXAMPLE_CONDITIONS_OBJECT = [
        'from' => '2019-01-01',
        'to' => '2019-01-31',
        'adults' => 2,
        'rooms' => 1,
        'currency' => 'SIM'
    ];

    public function fetchOffersList(FunctionalTester $I)
    {
        $I->amGoingTo("Fetch offers");
        $I->sendGET('/offers', self::EXAMPLE_CONDITIONS_OBJECT);
        $I->seeResponseCodeIs(HttpCode::OK);
        $I->seeResponseIsJson();
        $I->seeResponseMatchesJsonType([
            'offers' => 'array' //even empty
        ]);
        $I->seeResponseJsonMatchesJsonPath('$.offers[*].uuid');
    }
}