<?php

/**
 * This file contains the unit tests for ChannelPingController
 *
 * PHP Version 7
 *
 */

declare(strict_types=1);

namespace App\Tests\Controller;

use Mockery;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use App\Services\SystemValidatore;
use App\Services\ApiStatusChecker;
use App\Controller\ChannelPingController;
use Mockery\Adapter\Phpunit\MockeryTestCase;

/**
 * Unit tests for the ChannelPingController
 *
 * @coversDefaultClass App\Controller\ChannelPingController
 */
class ChannelPingControllerTest extends MockeryTestCase
{
    /** @var ApiStatusChecker $apiStatusChecker The ApiStatusChecker mock */
    private $apiStatusChecker;

    /** @var ParameterBagInterface $params The ParameterBagInterface mock */
    private $params;

    /** @var SystemValidatore $systemValidatore The SystemValidatore mock */
    private $systemValidatore;

    /** @var Mockery\MockInterface $containerMock The container mock */
    private $containerMock;

    /** @var Request $request The Request mock */
    private $request;

    /** @var ChannelPingController $controller An instance of ChannelPingController */
    private $controller;
    
    /**
     * Set up test
     *

     */
    public function setUp(): void
    {
        $this->containerMock = Mockery::mock(ContainerInterface::class);
        $this->apiStatusChecker = Mockery::mock(ApiStatusChecker::class);
        $this->params = Mockery::mock(ParameterBagInterface::class);
        $this->systemValidatore = Mockery::mock(SystemValidatore::class);
        $this->request = Mockery::mock(Request::class);
        $this->controller = new ChannelPingController(
            $this->apiStatusChecker,
            $this->params,
            $this->systemValidatore
        );
    }
    
    /**
     * Tests getPingStatus method
     *
     * @covers ::getPingStatus

     */
    public function testGetPingStatus()
    {
        $system = 'testSystem';
        $authorization = 'sdgf5g4g4f4gfdg4d4fg4z444';
        $suburl1 = 'bookingusbv4/ping';
        $suburl2 = 'shoppingenginev4/ping';
        $data = [
            'authorization' => $authorization,
            'method' => 'GET',
            'url' => $suburl1
        ];
        $request = new Request();
        $request->headers->set('authorization', $authorization);
        $request->query->set('system', $system);
        $response = Mockery::mock(JsonResponse::class);
        $this->request->shouldReceive('query')
            ->shouldReceive('get')
            ->twice()
            ->with('system')
            ->andReturn($system);
        $this->request->shouldReceive('headers')
            ->shouldReceive('get')
            ->twice()
            ->with('authorization')
            ->andReturn($authorization);
        $this->params->shouldReceive('get')
            ->once()
            ->with('bookingUSBPingUrl')
            ->andReturn($suburl1);
        $this->params->shouldReceive('get')
            ->once()
            ->with('shoppingEnginPingUrl')
            ->andReturn($suburl2);
        $this->systemValidatore->shouldReceive('validate')
            ->once()
            ->with($system)
            ->andReturn(false);
        $this->apiStatusChecker->shouldReceive('getStatus')
            ->once()
            ->with($data)
            ->andReturn($response);
        $data['url'] = $suburl2;
        $this->apiStatusChecker->shouldReceive('getStatus')
            ->once()
            ->with($data)
            ->andReturn($response);
        $statusCode = $response->shouldReceive('getStatusCode')
            ->twice()
            ->with()
            ->andReturn(200);
        $this->containerMock->shouldReceive('pingResponseByStatus')
            ->once()
            ->with($system, $statusCode, $statusCode)
            ->andReturn($response);
        $controllerResponse = $this->controller->getPingStatus($request);
        $this->assertInstanceOf(JsonResponse::class, $controllerResponse);
        $this->assertEquals(200, $controllerResponse->getStatusCode());
    }
}
