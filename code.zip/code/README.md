# derbysoft-adapter

Dear developers,

We are happy to have more people on board. The first thing you should read
in this repository is the docs. They will prevent some questions. :)

This is an Adapter from Bidroom internal interface to DerbySoft API. 
The bigger file (Internal CMM interfaces) contains the description of
the Bidroom interface. The smaller file (Adapter Interface) specifies
how to expose it, so it can be called by Bidroom systems.

(Ignore todos in the docs - these are to be done by BID empolyees.)

The "other side" onto which you are going to adapt (DerbySoft API)
is described sepatarely. You should receive you credentials
to DerbySoft console, where you can read it.

You should also have access to a Jira project where we track the progress.
There is already a rough breakdown of the work that needs to be done.
After you give us your GitHub accounts, we will give you also the access
to a git repository, where you will check out all code.

The usual way of work is:

 - Assign a task from Jira to yourself
 - Set it as "in progress"
 - Create a feature branch from the master (e. g. AD-18-expose-API)
 - Commit your work (both the code and the test) to that branch
   (at least once every day, in commits under 100 non-trivial linechanges)
 - When the task is done, run tests to make sure you didn't break anything
   (if you did, fix either the code or the test)
 - Make a pull request in GitHub from the feature branch to master
 - Set the Jira task as "in review/testing" (*)
 - Wait for Bidroom developers to review the code
  (then fix your code according to the comments if needed)
 - Wait for Bidroom developers to merge your code into the master

To prevent idle time, a developer should get a second task
when reaching the asterisk (*) above, and return to the code review later.

After you get the access to both Jira and our git repository, you can start
right away on tasks in story AD-16. You will find the Dummy adapter
that we are currently using for our internal testing in the docs directory.
It is ugly, throwaway code... but it may give you an idea about the setup.
If you still have any questions after consulting its code,
feel free to contact Martin me at our common Slack.

There is also one technical detail that needs to be mentioned up-front:
you are going to use Bidroom Domain, a library that is still in development.
We will have to introduce some backward-incompatible changes in the library
at some point in time. Please, don't automatically advance
to the newest version of the library. Stay safe at version 0.23.2,
until explicitly advised to advance to next stable version.

## Technology
- PHP 7.3
- Current Symfony version

## Quality
### Code style
- Code should fulfill PSR-2 standards
- Code should fulfill best clear code practices such as SOLID, YAGNI, KISS, DRY.
- Code should be protected against vulnerabilities mentioned in [OWASP 10](https://www.owasp.org/images/7/72/OWASP_Top_10-2017_%28en%29.pdf.pdf)
- Specification from [RFC](http://standards.rest/) should be fulfilled

### Setup development environment
```bash
$ .build/run_local.sh
```
The project will be accessible on port: 7777, i.e. http://localhost:7777

### Tests
All functional tests have to pass. To run tests use:
```bash
$ vendor/bin/codecept run
```

There is Phpunit already installed (with Codeception).
Classes without logic (data structure), can be skipped and not tested.
