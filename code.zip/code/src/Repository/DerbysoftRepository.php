<?php
namespace App\Repository;

use App\Service\ChannelUrl;
use App\Service\ExternalApiClient;

class DerbysoftRepository
{
    /**
     * Construct function
     *
     * @param Client $client
     */
    public function __construct(
        $base_url,
        $authorization_token,
        $distributor_id,
        ExternalApiClient $apiClient
    ) {
        $this->apiClient = $apiClient;
        $this->baseUrl = $base_url;
        $this->distributorId = $distributor_id;
        $this->authorizationToken = $authorization_token;
    }

    public function ping()
    {
        $url = $this->baseUrl.ChannelUrl::BOOKING_USB['ping'];
        $query = ['distributorId' => $this->distributorId ];
        $headers = ['Authorization' => $this->authorizationToken];
        return $this->apiClient->get($url, $query, $headers);
    }
}
