<?php
namespace App\Repository;

class ShoppingEngineRepository
{
}
