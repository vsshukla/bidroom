<?php
/**
 * This file contains the class for checking ping status of both channel.
 *
 * PHP version 7.3
 *
 */
declare(strict_types=1);

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use App\Service\DerbysoftClient;

class AdapterController extends AbstractController
{


    /**
     * AdapterController constructor.
     * @param DerbysoftClient $derbysoft
     */
    public function __construct(DerbysoftClient $derbysoft)
    {
        $this->derbysoftClient = $derbysoft;
    }

    /**
     * @param $system
     * @return Void
     */
    public function ping($system)
    {
        $response = $this->derbysoftClient->ping($system);
        
        return $this->json([$response]);
    }
}
