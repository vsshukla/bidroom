<?php
/**
 * This file contains the class for Channels URI.
 *
 * PHP version 7.3
 *
 */

declare(strict_types=1);

namespace App\Service;

/**
 * Class for create channels URI
 */
class ChannelUrl
{
    /** @var BOOKING_USB list of booking chanel URI */
    const BOOKING_USB = [
        'ping'=>'bookingusbv4/ping',

    ];

    /** @var SHOPPING_ENGINE list of shoppingEngine Channel URI */
    const SHOPPING_ENGINE = [
        'ping'=>'shoppingenginev4/ping',
    ];
}
