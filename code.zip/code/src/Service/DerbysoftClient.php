<?php
namespace App\Service;

use App\Validator\ValidateRequest;
use App\Repository\DerbysoftRepository;

class DerbysoftClient
{
    private $derbysoftRepository;
    private $validator;
   
    public function __construct(DerbysoftRepository $derbysoftRepository, ValidateRequest $validator)
    {
        $this->derbysoftRepository = $derbysoftRepository;
        $this->validator = $validator;
    }

    public function ping(string $system)
    {
        if ($this->validator->validate($system)) {
            return $this->derbysoftRepository->ping();
        }
    }
}
