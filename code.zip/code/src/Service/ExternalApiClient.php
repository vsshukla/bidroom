<?php

namespace App\Service;

use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Response;

class ExternalApiClient
{
    /**
     * Class constructor.
     */
    public function __construct(Client $client)
    {
        $this->client = $client;
    }
    
    //GET Request
    public function get($url, $query, $headers): Response
    {
        $response = $this->client->get(
            $url,
            [
                'query' => $query,
                'headers' => $headers
            ]
        );
        return $response;
    }

    //POST Request
    public function post($url, $query, $headers)
    {
        $response = $this->client->post(
            $url,
            [
                'query' => $query,
                'headers' => $headers
            ]
        );
        return $response;
    }
}
