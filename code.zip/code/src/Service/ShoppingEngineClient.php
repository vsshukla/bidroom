<?php

namespace App\Service;

/**
 * Class ShoppingEngineClient
 * @package App\Service
 */

class ShoppingEngineClient
{
}
