<?php
namespace App\Validator;

use Symfony\Component\Validator\Validation;
use Symfony\Component\Validator\Constraints as Assert;

class ValidateRequest
{
    const SYSTEM = 'derbysoft';
    public function validate(string $system)
    {
        $validator = Validation::createValidator();
        $violations = $validator->validate(
            $system,
            [
                new assert\Length(['max' => 12]),
                new assert\NotBlank(),
                new Assert\EqualTo(self::SYSTEM)
                ]
            );

        return (0 !== count($violations))? true : false;
    }
}
